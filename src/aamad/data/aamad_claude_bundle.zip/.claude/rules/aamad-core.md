## Purpose
- Define universal principles, contracts, and invariants for AI-assisted, multi-agent development, independent of any specific execution framework.

## Principles
- **Single responsibility personas:** each persona owns a defined epic with explicit inputs, outputs, and prohibited actions.
- **Context-first engineering:** all outputs must trace to PRD, SAD, SFS, or user stories; do not invent requirements.
- **Reproducibility and provenance:** every artifact includes Sources, Assumptions, and Open Questions sections.
- **Deterministic execution:** actions are idempotent; perform temp-write-then-atomic-replace for file outputs.
- **Minimal viable architecture first:** implement MVP scope before expanding; document deferrals with rationale.

## Agent Contract
- Personas declare: id, role, instructions, actions, inputs, outputs, prohibited-actions. Agents MUST read only declared inputs and write only to declared outputs.
- On missing/ambiguous inputs, write Assumptions and Open Questions; do not fabricate content.
- All actions must append an Audit block with timestamp, persona id, and action name to the artifact.

## Task Contract
- Each task defines: description, expected_output (exact target file path and required headings), acceptance_criteria, traceability to PRD/SAD/SFS anchors.
- Tasks include a self-check verifying required headings; if missing, write Diagnostic and halt.

## Tooling Rules
- Use only approved file and validation tools provided by the active adapter; no direct shell or network unless explicitly authorized by persona.
- Log tool usage in the artifact, including model, temperature, and max_tokens impacting determinism.

## State and Output
- Outputs follow template headings exactly (.cursor/templates). Do not wrap machine-parsed blocks in code fences if templates require raw content.
- Artifacts end with sections: Sources, Assumptions, Open Questions, Audit.

## Adapter Abstraction
- The active framework adapter binds: framework agent, task, tool, execution controls, logging. Personas/tasks remain adapter-neutral.

## Failure Policy
- On iteration/time limits or missing prerequisites, write a Halt and Report section with blockers; do not continue.

## Security and Compliance
- Never embed secrets in artifacts; use environment variables in runtime code only. Record third-party content in NOTICES as needed