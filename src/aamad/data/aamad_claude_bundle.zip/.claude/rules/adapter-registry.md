# Adapter Registry Rules

## Purpose
- Select the runtime target for the generated multi-agent application without changing AAMAD's core crew workflow.

## Selection Mechanism
- Use environment variable `AAMAD_TARGET_RUNTIME` with values:
    - `crewai` (default)
    - `claude-agent-sdk`
    - `cursor-sdk`
- Runtime adapter rules are loaded from `.claude/rules/adapter-<name>.md`; selected runtime should have a matching adapter file.
- If unset or unknown, default to `crewai` and record the resolved value plus warning in the artifact Audit.

## Adapter Contract
- Each adapter must define:
    - Setup requirements (dependencies, env vars, and runtime prerequisites).
    - Agent declaration pattern for the generated application (how runtime agents/subagents are represented).
    - Tool and MCP binding policy, including validation and least-privilege guidance.
    - Execution controls (iteration/time/budget caps, retries, and cancellation behavior).
    - Logging hooks for Prompt Trace, Diagnostic, and Audit sections.
    - Memory/session handling and reproducibility constraints.
    - Output contract conventions (structured I/O, schema checks, citation/grounding rules when applicable).

## Runtime Hooks
- Preflight: verify PRD/SAD/SFS presence per persona, validate runtime/tool config, resolve runtime value, then proceed or Halt and Report.
- Postflight: validate artifact against template schema, append Prompt Trace + Audit, ensure deterministic write.

## Extensibility
- New adapters must keep the same section taxonomy: Purpose, Setup, Mapping, Execution, Tools, Logging, Quality Gates, Failure Policy.
- Adapters may add capabilities (e.g., graph supervision) but cannot change AAMAD Core contracts.

## Selection Criteria
- `crewai`: best when you want declarative task orchestration with YAML-first config and explicit task graph controls.
- `claude-agent-sdk`: best when you want an agentic runtime harness with hooks, custom tools/MCP integration, and session-level control.
- `cursor-sdk`: best when you want TypeScript-first runtime integration with Cursor-native harness capabilities and explicit tool/runtime contracts.

## Usage
- Operators set `AAMAD_TARGET_RUNTIME` before Build-phase implementation work; personas align generated runtime code and docs to `.claude/rules/adapter-${AAMAD_TARGET_RUNTIME}.md`.