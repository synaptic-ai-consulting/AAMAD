# Adapter Registry Rules

## Purpose
- Allow AAMAD to select an execution adapter without modifying personas, enabling CrewAI now and future frameworks later.

## Selection Mechanism
- Use environment variable AAMAD_ADAPTER with values:
    - crewai (default)
    - langgraph (future)
    - other names map to .claude/rules/adapter-<name>.md if present.
- If unset or unknown, default to crewai and record a warning in the artifact Audit.

## Adapter Contract
- Each adapter must define:
    - Mapping from persona task contract to framework agent/task with expected_output enforcement.
    - Tool whitelist policy and configuration validation steps.
    - Execution controls: iteration/time limits, retries, failure policy.
    - Logging hooks to append Prompt Trace, Diagnostic, and Audit sections.

## Runtime Hooks
- Preflight: verify PRD/SAD/SFS presence per persona, validate tool configs, render expected headings, then proceed or Halt and Report.
- Postflight: validate artifact against template schema, append Audit, ensure deterministic write.

## Extensibility
- New adapters must keep the same section taxonomy: Purpose, Setup, Mapping, Execution, Tools, Logging, Quality Gates, Failure Policy.
- Adapters may add capabilities (e.g., graph supervision) but cannot change AAMAD Core contracts.

## Usage
- Operators set AAMAD_ADAPTER before running agents; the orchestrator loads .claude/rules/adapter-${AAMAD_ADAPTER}.md automatically.