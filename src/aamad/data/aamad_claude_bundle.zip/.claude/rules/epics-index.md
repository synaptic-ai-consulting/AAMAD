# AAMAD Phase 2 Epics Index Rule

| Epic         | Persona        | Primary Output Artifact | PRD/SAD Section Reference      | Invocation        |
|--------------|---------------|------------------------|-------------------------------|-------------------|
| Setup        | @project.mgr   | setup.md               | SAD: Environment, PRD: Setup   | *setup-project    |
| Frontend     | @frontend.eng  | frontend.md            | SAD: MVP UI, PRD: UI Scope     | *develop-fe       |
| Backend      | @backend.eng   | backend.md             | SAD: Crew Spec, PRD: Agent Def | *develop-be       |
| Integration  | @integration.eng | integration.md       | SAD: API & Flows, PRD: Int Req | *integrate-api    |
| QA           | @qa.eng        | qa.md                  | SAD: Testing, PRD: QA Plan     | *qa               |

## Execution Notes
- Each persona works independently referencing PRD.md and SAD.md.
- Output artifact for each epic lives in docs/ as [epic].md.
- Mark “future work” visibly in UI and docs as needed.
- Update this index as epics progress or new ones are added.