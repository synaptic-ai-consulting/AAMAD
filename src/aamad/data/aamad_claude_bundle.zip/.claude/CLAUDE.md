# AAMAD Framework Rules

This project uses the AAMAD multi-agent development framework.
All rules are loaded from `.claude/rules/`.

## Rule Files
- [aamad-core](.claude/rules/aamad-core.md)
- [development-workflow](.claude/rules/development-workflow.md)
- [epics-index](.claude/rules/epics-index.md)
- [adapter-registry](.claude/rules/adapter-registry.md)
- [adapter-crewai](.claude/rules/adapter-crewai.md)

---

For detailed agent/epic/action mapping, see `.claude/rules/epics-index.md`.